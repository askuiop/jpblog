Super Flat Remix GNOME theme
===========

This theme is available for use under a Creative Commons ShareAlike license.

Super Flat remix GNOME theme is a pretty simple shell theme, derived from [Paper](http://snwh.org/paper/) theme. Its design is mostly flat with a subtle use of shadows, highlights and gradients for some depth.

![alt tag](http://i1123.photobucket.com/albums/l553/mikelon1/screenshot1.jpg~original)
![alt tag](http://i1123.photobucket.com/albums/l553/mikelon1/screenshot2.jpg~original)

This theme was designed to fit with the [Super Flat Remix icon theme](http://the-ilife.com/post/127).

![alt tag](http://i1123.photobucket.com/albums/l553/mikelon1/screenshot3.jpg~original)
